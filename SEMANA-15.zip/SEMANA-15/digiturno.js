function info(){
    let num=1;
    let rest=true;
    while (num<=99 && res==true){
        nomuse=prompt("INGRESE SU NOMBRE DE USUARIO");
        if (nomuser!=nu11){
            var n=num.toString().padStart(2,'0');
            var letra="F";
            var letra=letra.concat(n);
            //imprimir titulo
            res=confirm("ESTIMADO USUARIO"+" "+"" +nomber+"\n"+"SU TURNO ES..."+" "+letra);
        }else{
            alert("ERROR TURNO...");
            break;
        }
    }
}
    function pago(){
        let num=1;
        let rest=true;
        while (num<=99 && res==true){
            nomuse=prompt("INGRESE SU NOMBRE DE USUARIO");
            if (nomuser!=nu11){
                var n=num.toString().padStart(2,'0');
                var letra="P";
                var letra=letra.concat(n);
                //imprimir titulo
                res=confirm("ESTIMADO USUARIO"+" "+"" +nomber+"\n"+"SU TURNO ES..."+" "+letra);
                
            }else{
                alert("ERROR TURNO...");
                break;
            }
        }
}

function pqr(){
    let num=1;
    let rest=true;
    while (num<=99 && res==true){
        nomuse=prompt("INGRESE SU NOMBRE DE USUARIO");
        if (nomuser!=nu11){
            var n=num.toString().padStart(2,'0');
            var letra="U";
            var letra=letra.concat(n);
            //imprimir titulo
            res=confirm("ESTIMADO USUARIO"+" "+"" +nomber+"\n"+"SU TURNO ES..."+" "+letra);
        }else{
            alert("ERROR TURNO...");
            break;
        }
    }
}

function matri(){
    let num=1;
    let rest=true;
    while (num<=99 && res==true){
        nomuse=prompt("INGRESE SU NOMBRE DE USUARIO");
        if (nomuser!=nu11){
            var n=num.toString().padStart(2,'0');
            var letra="M";
            var letra=letra.concat(n);
            //imprimir titulo
            res=confirm("ESTIMADO USUARIO"+" "+"" +nomber+"\n"+"SU TURNO ES..."+" "+letra);
        }else{
            alert("ERROR TURNO...");
            break;
        }
    }
}